/*
 * Copyright (c) 2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/clock_control.h>
#include <zephyr/drivers/gpio.h>

#include <zephyr/logging/log.h>
#include <zephyr/drivers/ieee802154/cc1200.h>
#include <zephyr/net/ieee802154_radio.h>
#include <zephyr/net/net_if.h>
LOG_MODULE_REGISTER(min_application, LOG_LEVEL_INF);

/* 1000 msec = 1 sec */
#define SLEEP_TIME_MS   500

#define LED0_NODE DT_ALIAS(led0)
#define CC1201_DEVICE DT_NODELABEL(spi_cc1200)

static const struct gpio_dt_spec led0 = GPIO_DT_SPEC_GET(LED0_NODE, gpios);
//static const struct net_if cc1201_if = NET_IF_GET(CC1201_DEVICE, 0);




void main(void)
{
	gpio_pin_configure_dt(&led0, GPIO_OUTPUT_ACTIVE);
	LOG_INF("Test on connection TI");
//	const struct ieee802154_radio_api *radio =
//		net_if_get_device(&cc1201_if)->api;
//	if (!radio) {
//		return -ENOENT;
//	}
//	return radio->start(net_if_get_device(&cc1201_if));

	while (1) {
		gpio_pin_set_dt(&led0, (int)1);
		k_msleep(SLEEP_TIME_MS);
		gpio_pin_set_dt(&led0, (int)0);
		k_msleep(SLEEP_TIME_MS);
	}

}
